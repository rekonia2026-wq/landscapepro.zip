import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function POST(req) {
  try {
    const { messages, project } = await req.json()

    const system = `Tu es un architecte paysagiste expert basé en Belgique (Brabant Wallon), avec 20 ans d'expérience.
Projet en cours: terrain ${project.w}×${project.h}m, ${project.objCount} éléments placés (${project.summary}).
Budget estimé: ${project.budget}€ TTC.

Réponds en français, de façon concise et très professionnelle. Maximum 150 mots.
Donne des conseils précis, chiffrés si pertinent. Suggère des améliorations concrètes.
Tu peux recommander des végétaux adaptés au climat belge, des matériaux locaux, des tendances 2025.`

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 400,
      system,
      messages: messages.slice(-10),
    })

    return Response.json({ content: response.content[0].text })
  } catch (err) {
    console.error(err)
    return Response.json({ error: 'Erreur IA' }, { status: 500 })
  }
}
