import './globals.css'

export const metadata = {
  title: 'LandscapePro — Logiciel d\'Architecture Paysagère',
  description: 'Conception paysagère professionnelle avec IA. Plan 2D, visualisation 3D, devis automatique.',
  icons: { icon: '/favicon.ico' },
}

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  )
}
