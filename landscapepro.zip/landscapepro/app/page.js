'use client'
import { useState, useCallback, Suspense } from 'react'
import dynamic from 'next/dynamic'
import { useStore, LIBRARY } from './lib/store'
import Topbar from './components/ui/Topbar'
import Sidebar from './components/ui/Sidebar'
import Iconbar from './components/ui/Iconbar'
import RightPanel from './components/ui/RightPanel'
import Statusbar from './components/ui/Statusbar'

const Canvas2D = dynamic(() => import('./components/Canvas2D'), { ssr: false })
const Canvas3D = dynamic(() => import('./components/3d/Canvas3D'), { ssr: false })

export default function Home() {
  const { view, addObject } = useStore()
  const [toast, setToast] = useState({ msg: '', show: false })

  const notify = useCallback((msg) => {
    setToast({ msg, show: true })
    setTimeout(() => setToast(t => ({ ...t, show: false })), 2500)
  }, [])

  const handleDrop = useCallback((item) => {
    if (window.__canvasDrop) window.__canvasDrop(item)
    else {
      const cw = document.getElementById('canvas-wrap')
      if (!cw) return
      const r = cw.getBoundingClientRect()
      addObject(item, r.width / 2 + (Math.random() - .5) * 100, r.height / 2 + (Math.random() - .5) * 80)
    }
    notify(`${item.ic} ${item.n} ajouté !`)
  }, [addObject, notify])

  const handleQuick = useCallback((action) => {
    const map = {
      pool: ['Piscine & Eau', 'Piscine rectangulaire'],
      tree: ['Végétation', 'Chêne pédonculé'],
      light: ['Éclairage', 'Spot LED encastré'],
    }
    const [cat, name] = map[action] || []
    if (!cat) return
    const item = LIBRARY[cat]?.items.find(i => i.n === name)
    if (item) handleDrop(item)
  }, [handleDrop])

  return (
    <div style={{
      display: 'grid',
      gridTemplateRows: '52px 1fr 26px',
      gridTemplateColumns: '56px 240px 1fr 300px',
      height: '100vh',
      overflow: 'hidden',
      background: '#0a0c10',
    }}>
      <Topbar onNotif={notify} />
      <Iconbar onQuick={handleQuick} onNotif={notify} />
      <Sidebar onDrop={handleDrop} />

      {/* Main canvas area */}
      <div id="canvas-wrap" style={{ position: 'relative', overflow: 'hidden', background: '#0a0c10' }}>
        {view === '2d' && <Canvas2D />}
        {view === '3d' && (
          <Suspense fallback={<Loader text="Chargement de la vue 3D..." />}>
            <Canvas3D />
          </Suspense>
        )}
        {view === 'render' && <RenderView />}

        {/* Global toast */}
        <div style={{
          position: 'absolute', top: '50%', left: '50%',
          transform: 'translate(-50%,-50%)',
          background: '#00d4aa', color: '#0a0c10',
          borderRadius: 10, padding: '9px 20px',
          fontSize: 13, fontWeight: 700,
          pointerEvents: 'none', whiteSpace: 'nowrap',
          zIndex: 999, opacity: toast.show ? 1 : 0,
          transition: 'opacity .25s',
        }}>{toast.msg}</div>
      </div>

      <RightPanel />
      <Statusbar />
    </div>
  )
}

function Loader({ text }) {
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: '#0a0c10', color: '#4a5570', gap: 12,
    }}>
      <div style={{ fontSize: 32, animation: 'float 2s ease-in-out infinite' }}>🌿</div>
      <div style={{ fontSize: 13 }}>{text}</div>
    </div>
  )
}

function RenderView() {
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: '#0a0c10', color: '#7a8aaa', gap: 16,
    }}>
      <div style={{ fontSize: 48 }}>🎨</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: '#dde4f0' }}>Rendu Photoréaliste</div>
      <div style={{ fontSize: 12, color: '#4a5570', textAlign: 'center', maxWidth: 300 }}>
        Intégrez Stable Diffusion ou Midjourney API pour générer des rendus photoréalistes depuis votre plan 2D.
      </div>
      <button style={{
        background: '#00d4aa', color: '#0a0c10', border: 'none',
        borderRadius: 9, padding: '10px 22px', fontSize: 13, fontWeight: 700,
        cursor: 'pointer', marginTop: 8,
      }}>🚀 Activer le moteur de rendu</button>
    </div>
  )
}
