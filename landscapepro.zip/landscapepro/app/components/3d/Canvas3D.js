'use client'
import { Suspense, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Sky, Environment, Grid, Text } from '@react-three/drei'
import { useStore } from '../lib/store'

function Ground({ w, h }) {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0]} receiveShadow>
      <planeGeometry args={[w, h]} />
      <meshStandardMaterial color="#2d4a1e" roughness={0.9} metalness={0.0} />
    </mesh>
  )
}

function Terrain({ w, h }) {
  return (
    <>
      <Ground w={w} h={h} />
      <Grid
        args={[w, h]}
        cellSize={1}
        cellThickness={0.5}
        cellColor="#3d6b2a"
        sectionSize={5}
        sectionThickness={1}
        sectionColor="#4a8a35"
        fadeDistance={60}
        position={[0, 0, 0]}
      />
    </>
  )
}

function Obj3D({ obj }) {
  const ref = useRef()
  const it = obj.item

  useFrame((state) => {
    if (ref.current && it.cat === 'Végétation') {
      ref.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3 + obj.id) * 0.03
    }
  })

  // Scale: 1 unit = 1 metre, place on grid
  const scale = [it.w || 1, it.h || 1, it.w || 1]
  const px = (obj.x / 40) - 9
  const pz = (obj.y / 40) - 6

  const color = it.color3d || '#4a7c2d'

  if (it.cat === 'Végétation') {
    const h = Math.max(it.h, 1)
    return (
      <group ref={ref} position={[px, 0, pz]}>
        {/* Trunk */}
        <mesh position={[0, h * 0.2, 0]} castShadow>
          <cylinderGeometry args={[0.08, 0.12, h * 0.4, 8]} />
          <meshStandardMaterial color="#5c3d1e" roughness={0.9} />
        </mesh>
        {/* Canopy */}
        <mesh position={[0, h * 0.55, 0]} castShadow>
          <sphereGeometry args={[it.w * 0.4, 12, 12]} />
          <meshStandardMaterial color={color} roughness={0.8} />
        </mesh>
        {it.n.includes('Palmier') && (
          <mesh position={[0, h * 0.8, 0]} castShadow>
            <coneGeometry args={[it.w * 0.5, h * 0.4, 8]} />
            <meshStandardMaterial color={color} roughness={0.8} />
          </mesh>
        )}
      </group>
    )
  }

  if (it.cat === 'Piscine & Eau') {
    return (
      <group position={[px, 0, pz]}>
        <mesh position={[0, -0.25, 0]} receiveShadow>
          <boxGeometry args={[it.w, 0.5, it.h || it.w * 0.5]} />
          <meshStandardMaterial color="#e8f4f8" roughness={0.1} metalness={0.0} />
        </mesh>
        <mesh position={[0, -0.02, 0]}>
          <boxGeometry args={[it.w * 0.9, 0.02, (it.h || it.w * 0.5) * 0.9]} />
          <meshStandardMaterial color={color} roughness={0.0} metalness={0.2} transparent opacity={0.85} />
        </mesh>
      </group>
    )
  }

  if (it.cat === 'Revêtements') {
    return (
      <mesh position={[px, 0.01, pz]} receiveShadow>
        <boxGeometry args={[it.w, 0.08, it.h]} />
        <meshStandardMaterial color={color} roughness={0.7} />
      </mesh>
    )
  }

  if (it.cat === 'Structures') {
    return (
      <group position={[px, 0, pz]}>
        {it.n.includes('Pergola') ? (
          <>
            {[[-it.w/2, it.w/2], [-it.h/2, it.h/2]].flatMap(([a, b]) =>
              [[a, -it.w/4], [b, -it.w/4], [a, it.w/4], [b, it.w/4]].map((pos, i) => (
                <mesh key={i} position={[pos[0], 1.2, pos[1]]} castShadow>
                  <cylinderGeometry args={[0.06, 0.06, 2.4, 8]} />
                  <meshStandardMaterial color={color} roughness={0.8} />
                </mesh>
              ))
            )}
            <mesh position={[0, 2.5, 0]} castShadow>
              <boxGeometry args={[it.w, 0.08, it.h]} />
              <meshStandardMaterial color={color} roughness={0.8} wireframe />
            </mesh>
          </>
        ) : (
          <mesh position={[0, 0.5, 0]} castShadow>
            <boxGeometry args={[it.w, 1, it.h || 0.3]} />
            <meshStandardMaterial color={color} roughness={0.6} />
          </mesh>
        )}
      </group>
    )
  }

  // Default box
  return (
    <mesh position={[px, 0.3, pz]} castShadow>
      <boxGeometry args={[Math.max(it.w, 0.3), 0.6, Math.max(it.h || it.w, 0.3)]} />
      <meshStandardMaterial color={color} roughness={0.6} />
    </mesh>
  )
}

function Scene() {
  const { objects, terrainW, terrainH } = useStore()

  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight
        position={[20, 30, 20]}
        intensity={2}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-far={100}
        shadow-camera-left={-30}
        shadow-camera-right={30}
        shadow-camera-top={30}
        shadow-camera-bottom={-30}
      />
      <pointLight position={[-10, 10, -10]} intensity={0.5} color="#60a5fa" />
      <Sky sunPosition={[100, 20, 100]} turbidity={2} rayleigh={0.5} />
      <Environment preset="park" />
      <Terrain w={terrainW} h={terrainH} />
      {objects.map(obj => <Obj3D key={obj.id} obj={obj} />)}
      <OrbitControls
        enableDamping
        dampingFactor={0.08}
        minDistance={5}
        maxDistance={80}
        maxPolarAngle={Math.PI / 2 - 0.05}
      />
    </>
  )
}

export default function Canvas3D() {
  const { objects } = useStore()

  return (
    <div style={{ position: 'relative', flex: 1, background: '#0a0c10' }}>
      <Canvas
        shadows
        camera={{ position: [15, 18, 20], fov: 55 }}
        style={{ width: '100%', height: '100%' }}
        gl={{ antialias: true, toneMapping: 4, toneMappingExposure: 1.2 }}
      >
        <Suspense fallback={null}>
          <Scene />
        </Suspense>
      </Canvas>

      {/* 3D HUD */}
      <div style={{
        position: 'absolute', top: 12, left: 12,
        background: 'rgba(10,12,16,.85)', border: '1px solid #2e3850',
        borderRadius: 8, padding: '8px 14px', fontSize: 11, color: '#7a8aaa',
        lineHeight: 1.7,
      }}>
        <div style={{ color: '#00d4aa', fontWeight: 600, marginBottom: 4 }}>🎲 Vue 3D Temps Réel</div>
        <div>🖱️ Clic + glisser — Orbite</div>
        <div>🖱️ Scroll — Zoom</div>
        <div>🖱️ Clic droit — Panoramique</div>
        <div style={{ marginTop: 6, color: '#4f8fff' }}>
          {objects.length} objets — Three.js WebGL
        </div>
      </div>

      {!objects.length && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
          textAlign: 'center', color: '#4a5570',
        }}>
          <div style={{ fontSize: 48, marginBottom: 12, animation: 'float 3s ease-in-out infinite' }}>🌿</div>
          <div style={{ fontSize: 14, color: '#7a8aaa' }}>Placez des objets en vue 2D</div>
          <div style={{ fontSize: 11, color: '#4a5570', marginTop: 4 }}>Ils apparaîtront ici en 3D</div>
        </div>
      )}
    </div>
  )
}
