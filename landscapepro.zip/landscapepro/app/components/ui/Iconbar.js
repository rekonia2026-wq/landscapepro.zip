'use client'
import { useStore } from '../lib/store'

const TOOLS = [
  { id: 'select',  icon: '↖️',  tip: 'Sélection (V)' },
  { id: 'pan',     icon: '✋',  tip: 'Panoramique (H)' },
  null,
  { id: 'rect',    icon: '⬜',  tip: 'Zone rectangulaire' },
  { id: 'ellipse', icon: '⭕',  tip: 'Zone ellipse' },
  { id: 'path',    icon: '〰️',  tip: 'Allée / Chemin' },
  { id: 'measure', icon: '📏',  tip: 'Mesure' },
  { id: 'text',    icon: 'T',   tip: 'Texte' },
  null,
  { id: 'pool',    icon: '🏊',  tip: 'Piscine rapide', action: 'pool' },
  { id: 'tree',    icon: '🌳',  tip: 'Arbre',          action: 'tree' },
  { id: 'light',   icon: '💡',  tip: 'Éclairage',      action: 'light' },
  null,
  { id: 'grid',    icon: '⋮⋮',  tip: 'Grille', toggle: 'grid' },
  { id: 'snap',    icon: '🧲',  tip: 'Magnétisme', toggle: 'snap' },
]

export default function Iconbar({ onQuick, onNotif }) {
  const { tool, setTool, gridOn, snapOn, setGrid, setSnap } = useStore()

  const handleClick = (t) => {
    if (t.toggle === 'grid') { setGrid(!gridOn); onNotif('Grille: ' + (!gridOn ? 'Activée' : 'Désactivée')); return }
    if (t.toggle === 'snap') { setSnap(!snapOn); onNotif('Magnétisme: ' + (!snapOn ? 'Activé' : 'Désactivé')); return }
    if (t.action) { onQuick(t.action); return }
    setTool(t.id)
  }

  return (
    <div style={{
      background: '#0e1116',
      borderRight: '1px solid #252c3d',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      padding: '8px 0',
      gap: 1,
      width: 56,
      flexShrink: 0,
      overflow: 'hidden',
    }}>
      {TOOLS.map((t, i) => {
        if (!t) return <div key={i} style={{ width: 28, height: 1, background: '#252c3d', margin: '3px 0' }} />
        const isOn = t.toggle === 'grid' ? gridOn : t.toggle === 'snap' ? snapOn : tool === t.id
        return (
          <div key={t.id} style={{ position: 'relative' }}
            onMouseEnter={e => { const tip = e.currentTarget.querySelector('.tip'); if (tip) tip.style.opacity = 1 }}
            onMouseLeave={e => { const tip = e.currentTarget.querySelector('.tip'); if (tip) tip.style.opacity = 0 }}
          >
            <button onClick={() => handleClick(t)} title={t.tip} style={{
              width: 40, height: 40,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              borderRadius: 10,
              background: isOn ? 'rgba(0,212,170,.12)' : 'none',
              border: isOn ? '1px solid rgba(0,212,170,.25)' : '1px solid transparent',
              color: isOn ? '#00d4aa' : '#4a5570',
              fontSize: t.id === 'text' ? 13 : 18,
              cursor: 'pointer',
              transition: 'all .12s',
              fontFamily: 'inherit',
              fontWeight: t.id === 'text' ? 700 : 400,
            }}
              onMouseEnter={e => { if (!isOn) { e.currentTarget.style.background = '#181c25'; e.currentTarget.style.color = '#dde4f0' } }}
              onMouseLeave={e => { if (!isOn) { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = '#4a5570' } }}
            >
              {t.icon}
            </button>
            <div className="tip" style={{
              position: 'absolute', left: 48, top: '50%', transform: 'translateY(-50%)',
              background: '#1d2230', border: '1px solid #2e3850', borderRadius: 6,
              padding: '3px 9px', fontSize: 11, color: '#dde4f0',
              whiteSpace: 'nowrap', pointerEvents: 'none', opacity: 0,
              transition: 'opacity .1s', zIndex: 999,
            }}>{t.tip}</div>
          </div>
        )
      })}

      {/* IA button at bottom */}
      <div style={{ marginTop: 'auto' }}>
        <div style={{ width: 28, height: 1, background: '#252c3d', margin: '3px 14px 5px' }} />
        <button title="Assistant IA" style={{
          width: 40, height: 40,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: 10, background: 'none', border: '1px solid transparent',
          fontSize: 18, cursor: 'pointer', transition: 'all .12s',
        }}
          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(0,212,170,.1)' }}
          onMouseLeave={e => { e.currentTarget.style.background = 'none' }}
        >✨</button>
      </div>
    </div>
  )
}
