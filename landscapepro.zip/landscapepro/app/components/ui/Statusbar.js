'use client'
import { useStore } from '../lib/store'

export default function Statusbar() {
  const { tool, snapOn, zoom } = useStore()
  const toolNames = { select:'Sélection', pan:'Panoramique', rect:'Zone rect.', ellipse:'Zone ellipse', path:'Allée', measure:'Mesure', text:'Texte' }

  return (
    <div style={{
      gridColumn: '1/-1',
      background: '#0e1116',
      borderTop: '1px solid #252c3d',
      display: 'flex',
      alignItems: 'center',
      padding: '0 14px',
      gap: 16,
      height: 26,
      flexShrink: 0,
      fontSize: 10,
      color: '#4a5570',
    }}>
      <Item icon="↖️" label="Outil" value={toolNames[tool] || tool} />
      <Sep />
      <Item icon="🗂️" label="Calque" value="Végétation" />
      <Sep />
      <Item icon="📏" label="Grille" value="0.5m" />
      <Sep />
      <Item icon="🧲" label="Snap" value={snapOn ? '✅ Actif' : '❌ Inactif'} />
      <Sep />
      <Item icon="🔍" label="Zoom" value={Math.round(zoom * 100) + '%'} />
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 16 }}>
        <Sep />
        <Item icon="⚙️" label="Moteur" value="WebGL 2.0 + Three.js" />
        <Sep />
        <span style={{ color: '#22c55e', fontWeight: 600 }}>● Prêt</span>
      </div>
    </div>
  )
}

function Item({ icon, label, value }) {
  return (
    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <span>{icon}</span>
      <span>{label}:</span>
      <span style={{ color: '#7a8aaa', fontWeight: 500 }}>{value}</span>
    </span>
  )
}

function Sep() {
  return <div style={{ width: 1, height: 14, background: '#252c3d' }} />
}
