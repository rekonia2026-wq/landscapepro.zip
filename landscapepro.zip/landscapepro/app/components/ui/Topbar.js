'use client'
import { useStore } from '../lib/store'

export default function Topbar({ onNotif }) {
  const { view, setView } = useStore()

  return (
    <div style={{
      gridColumn: '1/-1',
      background: '#0e1116',
      borderBottom: '1px solid #252c3d',
      display: 'flex',
      alignItems: 'center',
      padding: '0 10px',
      gap: '2px',
      height: '52px',
      flexShrink: 0,
      zIndex: 10,
    }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginRight: '16px' }}>
        <div style={{
          width: 32, height: 32, background: '#00d4aa', borderRadius: 8,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 800, fontSize: 16, color: '#0a0c10', flexShrink: 0,
        }}>L</div>
        <span style={{ fontSize: 15, fontWeight: 700, color: '#dde4f0', letterSpacing: '-.3px', whiteSpace: 'nowrap' }}>
          Landscape<span style={{ color: '#00d4aa' }}>Pro</span>
        </span>
      </div>

      <Vsep />

      {/* View switcher */}
      {['2d', '3d', 'render'].map(v => (
        <TopBtn key={v} active={view === v} onClick={() => { setView(v); onNotif(v === '2d' ? '📐 Vue Plan 2D' : v === '3d' ? '🎲 Vue 3D interactive' : '🎨 Rendu photoréaliste') }}>
          {v === '2d' ? '📐 Plan 2D' : v === '3d' ? '🎲 Vue 3D' : '🎨 Rendu'}
        </TopBtn>
      ))}

      <Vsep />

      <TopBtn onClick={() => onNotif('💾 Projet sauvegardé !')}>💾 Enregistrer</TopBtn>
      <TopBtn onClick={() => onNotif('📥 Export PNG HD en cours...')}>📥 Exporter</TopBtn>
      <TopBtn onClick={() => onNotif('🔗 Lien client copié !')}>🔗 Partager</TopBtn>
      <TopBtn onClick={() => onNotif('📄 Devis PDF généré !')}>📄 Devis PDF</TopBtn>

      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 11, color: '#7a8aaa', display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#22c55e', display: 'inline-block' }}></span>
          Villa Beaumont — Brabant Wallon
        </span>
        <span style={{
          background: 'linear-gradient(135deg,#00d4aa,#4f8fff)',
          color: '#0a0c10', borderRadius: 5, padding: '2px 9px',
          fontSize: 10, fontWeight: 800, letterSpacing: '.5px',
        }}>STUDIO</span>
      </div>
    </div>
  )
}

function TopBtn({ children, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: active ? 'rgba(0,212,170,.1)' : 'none',
      border: 'none',
      color: active ? '#00d4aa' : '#7a8aaa',
      padding: '5px 11px',
      fontSize: 12,
      cursor: 'pointer',
      borderRadius: 7,
      transition: 'all .12s',
      whiteSpace: 'nowrap',
      fontFamily: 'inherit',
    }}
      onMouseEnter={e => { if (!active) { e.target.style.background = '#181c25'; e.target.style.color = '#dde4f0' } }}
      onMouseLeave={e => { if (!active) { e.target.style.background = 'none'; e.target.style.color = '#7a8aaa' } }}
    >{children}</button>
  )
}

function Vsep() {
  return <div style={{ width: 1, height: 24, background: '#252c3d', margin: '0 5px', flexShrink: 0 }} />
}
