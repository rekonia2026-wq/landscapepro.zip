'use client'
import { useState } from 'react'
import { useStore, LAYERS } from '../lib/store'

export default function RightPanel() {
  const [tab, setTab] = useState('props')

  return (
    <div style={{
      background: '#0e1116',
      borderLeft: '1px solid #252c3d',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      width: 300,
      flexShrink: 0,
    }}>
      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid #252c3d', flexShrink: 0, overflowX: 'auto' }}>
        {[
          { id: 'props',  label: '⚙️ Props' },
          { id: 'devis',  label: '📄 Devis' },
          { id: 'layers', label: '🗂️ Calques' },
          { id: 'stats',  label: '📊 Stats' },
          { id: 'ai',     label: '✨ IA' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, minWidth: 52, padding: '10px 4px',
            textAlign: 'center', fontSize: 10, fontWeight: 600,
            color: tab === t.id ? '#00d4aa' : '#4a5570',
            background: 'none', border: 'none',
            borderBottom: tab === t.id ? '2px solid #00d4aa' : '2px solid transparent',
            cursor: 'pointer', whiteSpace: 'nowrap', fontFamily: 'inherit',
            transition: 'all .12s',
          }}>{t.label}</button>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {tab === 'props'  && <PropsPanel />}
        {tab === 'devis'  && <DevisPanel />}
        {tab === 'layers' && <LayersPanel />}
        {tab === 'stats'  && <StatsPanel />}
        {tab === 'ai'     && <AIPanel />}
      </div>
    </div>
  )
}

/* ── PROPS ── */
function PropsPanel() {
  const { selected, objects, updateObject, deleteObject, duplicateObject, terrainW, terrainH, setTerrain } = useStore()
  const obj = objects.find(o => o.id === selected)

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
      <SectionLabel>Terrain du projet</SectionLabel>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 12 }}>
        <Field label="Largeur (m)">
          <input className="rpinput" defaultValue={terrainW} onBlur={e => setTerrain(+e.target.value || 18, terrainH)} style={INP} />
        </Field>
        <Field label="Hauteur (m)">
          <input className="rpinput" defaultValue={terrainH} onBlur={e => setTerrain(terrainW, +e.target.value || 12)} style={INP} />
        </Field>
      </div>

      {!obj && (
        <div style={{ color: '#4a5570', fontSize: 11, textAlign: 'center', padding: '20px 0' }}>
          Sélectionnez un objet sur le plan
        </div>
      )}

      {obj && (
        <>
          <SectionLabel>Objet sélectionné</SectionLabel>
          <div style={{ background: '#181c25', border: '1px solid #252c3d', borderRadius: 10, padding: 12, marginBottom: 12 }}>
            <div style={{ fontSize: 24, marginBottom: 6 }}>{obj.item.ic}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#dde4f0' }}>{obj.item.n}</div>
            <div style={{ fontSize: 10, color: '#4a5570', marginTop: 2 }}>{obj.item.cat} — {obj.item.w}m × {obj.item.h}m</div>
          </div>

          <SectionLabel>Rotation</SectionLabel>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <input type="range" min="0" max="359" step="1" defaultValue={obj.rot || 0}
              onChange={e => updateObject(obj.id, { rot: +e.target.value })}
              style={{ flex: 1 }} />
            <span style={{ fontSize: 11, color: '#00d4aa', minWidth: 32 }}>{obj.rot || 0}°</span>
          </div>

          <SectionLabel>Coût unitaire</SectionLabel>
          {[
            ['Matériaux', obj.item.mat.toLocaleString() + '€', '#00d4aa'],
            ['Pose',      obj.item.pose.toLocaleString() + '€', '#dde4f0'],
            ['Total TTC', Math.round((obj.item.mat + obj.item.pose) * 1.21).toLocaleString() + '€', '#00d4aa'],
            ['Main d\'œuvre', (obj.item.mo || 0) + 'h', '#f0b429'],
          ].map(([k, v, c]) => (
            <KV key={k} label={k} value={v} color={c} />
          ))}

          <button onClick={() => duplicateObject(obj.id)} style={{ ...BTN_OUT, marginTop: 12 }}>📋 Dupliquer</button>
          <button onClick={() => deleteObject(obj.id)} style={{ ...BTN_DANGER, marginTop: 6 }}>🗑️ Supprimer</button>
        </>
      )}
    </div>
  )
}

/* ── DEVIS ── */
function DevisPanel() {
  const { getDevis, marge, setMarge } = useStore()
  const [fraisDep, setFraisDep] = useState(200)
  const [fraisMach, setFraisMach] = useState(450)
  const [moTaux, setMoTaux] = useState(55)
  const d = getDevis()
  const totalMO = d.moH * moTaux
  const base = d.ht + fraisDep + fraisMach + totalMO
  const htM = base * (1 + marge / 100)
  const tva = htM * 0.21
  const ttc = htM + tva

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
      <SectionLabel>Postes de travaux</SectionLabel>
      {d.lines.length === 0 && (
        <div style={{ color: '#4a5570', fontSize: 11, textAlign: 'center', padding: '12px 0' }}>
          Aucun objet sur le plan
        </div>
      )}
      {d.lines.map(l => (
        <div key={l.name} style={{ padding: '7px 0', borderBottom: '1px solid #252c3d', display: 'flex', justifyContent: 'space-between', fontSize: 11 }}>
          <div>
            <div style={{ color: '#dde4f0', fontWeight: 500 }}>{l.ic} {l.name}</div>
            <div style={{ color: '#4a5570', fontSize: 10 }}>×{l.qty} — {l.mat}€ mat + {l.pose}€ pose</div>
          </div>
          <div style={{ color: '#f0b429', fontWeight: 600 }}>{Math.round(l.sub).toLocaleString()}€</div>
        </div>
      ))}

      <SectionLabel style={{ marginTop: 14 }}>Frais additionnels</SectionLabel>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        <Field label="Déplacement €"><input type="number" value={fraisDep} onChange={e => setFraisDep(+e.target.value)} style={INP} /></Field>
        <Field label="Machines €"><input type="number" value={fraisMach} onChange={e => setFraisMach(+e.target.value)} style={INP} /></Field>
      </div>
      <Field label="Main d'œuvre (€/h)" style={{ marginTop: 6 }}>
        <input type="number" value={moTaux} onChange={e => setMoTaux(+e.target.value)} style={INP} />
      </Field>

      <SectionLabel>Marge bénéficiaire</SectionLabel>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
        <input type="range" min="5" max="50" step="1" value={marge} onChange={e => setMarge(+e.target.value)} style={{ flex: 1 }} />
        <span style={{ fontSize: 11, color: '#00d4aa', minWidth: 36 }}>{marge}%</span>
      </div>

      {/* Total */}
      <div style={{ background: 'rgba(0,212,170,.06)', border: '1px solid rgba(0,212,170,.2)', borderRadius: 9, padding: 12 }}>
        {[
          ['Matériaux + pose HT', Math.round(d.ht).toLocaleString() + '€'],
          ['Main d\'œuvre (' + d.moH + 'h)', Math.round(totalMO).toLocaleString() + '€'],
          ['Frais divers', (fraisDep + fraisMach).toLocaleString() + '€'],
          ['Marge ' + marge + '%', Math.round(htM - base).toLocaleString() + '€'],
          ['TVA 21%', Math.round(tva).toLocaleString() + '€'],
        ].map(([k, v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 4 }}>
            <span style={{ color: '#7a8aaa' }}>{k}</span>
            <span style={{ color: '#dde4f0' }}>{v}</span>
          </div>
        ))}
        <div style={{ borderTop: '1px solid rgba(0,212,170,.2)', paddingTop: 8, marginTop: 6, display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 700, color: '#00d4aa' }}>
          <span>TOTAL TTC CLIENT</span>
          <span>{Math.round(ttc).toLocaleString()}€</span>
        </div>
      </div>

      <button style={{ ...BTN_ACC, marginTop: 12 }}>📄 Générer devis PDF</button>
      <button style={{ ...BTN_OUT, marginTop: 6 }}>📋 Liste matériaux</button>
      <button style={{ ...BTN_OUT, marginTop: 6 }}>📅 Planning chantier</button>
    </div>
  )
}

/* ── LAYERS ── */
function LayersPanel() {
  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
      <SectionLabel>Calques du projet</SectionLabel>
      {LAYERS.map((l, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0', borderBottom: '1px solid #252c3d', cursor: 'pointer' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: l.color, flexShrink: 0 }} />
          <span style={{ flex: 1, fontSize: 11, color: '#dde4f0' }}>{l.n}</span>
          <span style={{ fontSize: 14, color: '#4a5570' }}>👁️</span>
          <span style={{ fontSize: 14, color: '#4a5570' }}>⋮</span>
        </div>
      ))}
      <button style={{ ...BTN_OUT, marginTop: 12 }}>+ Nouveau calque</button>
    </div>
  )
}

/* ── STATS ── */
function StatsPanel() {
  const { objects, terrainW, terrainH, getDevis } = useStore()
  const d = getDevis()
  const surf = terrainW * terrainH
  const cats = {}
  objects.forEach(o => { cats[o.item.cat] = (cats[o.item.cat] || 0) + (o.item.mat + o.item.pose) })
  const total = Object.values(cats).reduce((a, b) => a + b, 0) || 1

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 14 }}>
      <SectionLabel>Synthèse projet</SectionLabel>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7, marginBottom: 14 }}>
        {[
          [Math.round(surf) + ' m²', 'Surface terrain'],
          [objects.length + '', 'Objets placés'],
          [objects.filter(o => o.item.cat === 'Végétation').length + '', 'Végétaux'],
          [Math.round(d.ttc || 0).toLocaleString() + '€', 'Budget TTC'],
        ].map(([val, lbl]) => (
          <div key={lbl} style={{ background: '#181c25', borderRadius: 9, padding: '10px 12px' }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: '#00d4aa', letterSpacing: '-.5px' }}>{val}</div>
            <div style={{ fontSize: 10, color: '#4a5570' }}>{lbl}</div>
          </div>
        ))}
      </div>

      <SectionLabel>Répartition budget</SectionLabel>
      {Object.entries(cats).map(([cat, v]) => {
        const pct = Math.round(v / total * 100)
        const col = Object.values(require('../lib/store').LIBRARY).find(d => d.items[0]?.cat === cat)?.color || '#60a5fa'
        return (
          <div key={cat} style={{ marginBottom: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: '#7a8aaa', marginBottom: 3 }}>
              <span>{cat}</span>
              <span style={{ color: '#dde4f0', fontWeight: 500 }}>{Math.round(v).toLocaleString()}€ ({pct}%)</span>
            </div>
            <div style={{ height: 5, background: '#181c25', borderRadius: 3 }}>
              <div style={{ height: '100%', width: pct + '%', background: col, borderRadius: 3, transition: 'width .4s' }} />
            </div>
          </div>
        )
      })}
    </div>
  )
}

/* ── AI ── */
function AIPanel() {
  const [msgs, setMsgs] = useState([
    { role: 'assistant', text: '🌿 Bonjour ! Je suis votre architecte paysagiste IA. Décrivez votre projet, posez vos questions sur les matériaux, plantes, budget...' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const { objects, terrainW, terrainH, getDevis, aiHistory, pushAI } = useStore()

  const SUGGESTS = [
    'Plantes pour mi-ombre en Belgique ?',
    'Optimise pour un budget 25 000€',
    'Quel revêtement autour de la piscine ?',
    'Temps de chantier estimé ?',
  ]

  const send = async (text) => {
    const msg = text || input.trim()
    if (!msg || loading) return
    setInput('')
    setMsgs(m => [...m, { role: 'user', text: msg }])
    setLoading(true)

    const d = getDevis()
    const summary = objects.map(o => o.item.n).join(', ') || 'aucun'
    try {
      const r = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...aiHistory, { role: 'user', content: msg }],
          project: { w: terrainW, h: terrainH, objCount: objects.length, summary, budget: Math.round(d.ttc || 0) }
        })
      })
      const data = await r.json()
      const reply = data.content || 'Désolé, erreur de réponse.'
      setMsgs(m => [...m, { role: 'assistant', text: reply }])
      pushAI('user', msg)
      pushAI('assistant', reply)
    } catch {
      setMsgs(m => [...m, { role: 'assistant', text: '❌ Connexion impossible.' }])
    }
    setLoading(false)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: 7 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{
            borderRadius: 10, padding: '8px 11px', fontSize: 11, lineHeight: 1.55,
            background: m.role === 'assistant' ? '#181c25' : 'rgba(79,143,255,.1)',
            border: `1px solid ${m.role === 'assistant' ? '#252c3d' : 'rgba(79,143,255,.2)'}`,
            textAlign: m.role === 'user' ? 'right' : 'left',
            color: '#dde4f0',
          }}>
            {m.role === 'assistant' && (
              <div style={{ fontSize: 9, fontWeight: 700, color: '#00d4aa', marginBottom: 4, letterSpacing: '.5px' }}>✨ IA PAYSAGISTE</div>
            )}
            {m.text}
          </div>
        ))}
        {loading && (
          <div style={{ background: '#181c25', border: '1px solid #252c3d', borderRadius: 10, padding: '10px 12px' }}>
            <div style={{ fontSize: 9, color: '#00d4aa', marginBottom: 6, fontWeight: 700 }}>✨ IA PAYSAGISTE</div>
            <span className="dot-1" style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: '#00d4aa', margin: '0 2px' }} />
            <span className="dot-2" style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: '#00d4aa', margin: '0 2px' }} />
            <span className="dot-3" style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: '#00d4aa', margin: '0 2px' }} />
          </div>
        )}
      </div>

      {/* Suggestions */}
      <div style={{ padding: '6px 12px 0', display: 'flex', flexWrap: 'wrap', gap: 4 }}>
        {SUGGESTS.map(s => (
          <button key={s} onClick={() => send(s)} style={{
            background: 'rgba(79,143,255,.08)', border: '1px solid rgba(79,143,255,.2)',
            color: '#4f8fff', borderRadius: 6, padding: '3px 8px', fontSize: 10,
            cursor: 'pointer', fontFamily: 'inherit', transition: 'all .12s',
          }}>{s}</button>
        ))}
      </div>

      {/* Input */}
      <div style={{ display: 'flex', gap: 6, padding: '8px 12px 10px', borderTop: '1px solid #252c3d', flexShrink: 0 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Posez votre question..."
          style={{ ...INP, flex: 1 }}
        />
        <button onClick={() => send()} style={{
          background: '#00d4aa', border: 'none', borderRadius: 8,
          width: 34, height: 34, cursor: 'pointer', fontSize: 16,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#0a0c10', flexShrink: 0, transition: 'opacity .12s',
        }}>↑</button>
      </div>
    </div>
  )
}

/* ── Helpers ── */
const INP = {
  width: '100%', background: '#181c25', border: '1px solid #252c3d',
  color: '#dde4f0', borderRadius: 7, padding: '6px 9px', fontSize: 12,
  outline: 'none', fontFamily: 'inherit',
}
const BTN_ACC = {
  background: '#00d4aa', color: '#0a0c10', border: 'none', borderRadius: 8,
  padding: '9px 14px', fontSize: 12, fontWeight: 700, cursor: 'pointer',
  width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
  gap: 6, fontFamily: 'inherit',
}
const BTN_OUT = {
  background: 'none', color: '#7a8aaa', border: '1px solid #2e3850',
  borderRadius: 8, padding: '8px 14px', fontSize: 12, cursor: 'pointer',
  width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
  gap: 6, fontFamily: 'inherit',
}
const BTN_DANGER = {
  background: 'none', color: '#e05c5c', border: '1px solid rgba(224,92,92,.3)',
  borderRadius: 8, padding: '8px 14px', fontSize: 12, cursor: 'pointer',
  width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
  gap: 6, fontFamily: 'inherit',
}

function SectionLabel({ children }) {
  return (
    <div style={{ fontSize: 9, fontWeight: 700, color: '#4a5570', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 7, marginTop: 14 }}>
      {children}
    </div>
  )
}

function KV({ label, value, color }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid #252c3d', fontSize: 11 }}>
      <span style={{ color: '#7a8aaa' }}>{label}</span>
      <span style={{ color: color || '#dde4f0', fontWeight: 500 }}>{value}</span>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: '#4a5570', marginBottom: 3 }}>{label}</div>
      {children}
    </div>
  )
}
