'use client'
import { useState } from 'react'
import { LIBRARY, useStore } from '../lib/store'

export default function Sidebar({ onDrop }) {
  const [q, setQ] = useState('')

  return (
    <div style={{
      background: '#0e1116',
      borderRight: '1px solid #252c3d',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      width: 240,
    }}>
      {/* Header */}
      <div style={{ padding: '12px 14px 8px', borderBottom: '1px solid #252c3d', flexShrink: 0 }}>
        <div style={{ fontSize: 9, fontWeight: 700, color: '#4a5570', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 8 }}>
          Bibliothèque
        </div>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', color: '#4a5570', fontSize: 14 }}>🔍</span>
          <input
            value={q}
            onChange={e => setQ(e.target.value)}
            placeholder="Rechercher..."
            style={{
              width: '100%',
              background: '#181c25',
              border: '1px solid #252c3d',
              color: '#dde4f0',
              borderRadius: 8,
              padding: '6px 10px 6px 30px',
              fontSize: 12,
              outline: 'none',
              fontFamily: 'inherit',
            }}
          />
        </div>
      </div>

      {/* Library */}
      <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        {Object.entries(LIBRARY).map(([cat, def]) => {
          const items = q ? def.items.filter(i => i.n.toLowerCase().includes(q.toLowerCase())) : def.items
          if (!items.length) return null
          return (
            <div key={cat}>
              <div style={{
                padding: '8px 14px 4px',
                display: 'flex', alignItems: 'center', gap: 6,
                fontSize: 11, fontWeight: 600, color: '#7a8aaa', letterSpacing: '.3px',
              }}>
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: def.color, display: 'inline-block', flexShrink: 0 }} />
                {cat}
                <span style={{ marginLeft: 'auto', fontSize: 10, color: '#4a5570' }}>{items.length}</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, padding: '4px 10px 10px' }}>
                {items.map(item => (
                  <ObjTile key={item.n} item={item} onDrop={onDrop} />
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function ObjTile({ item, onDrop }) {
  const [hov, setHov] = useState(false)

  return (
    <div
      onClick={() => onDrop(item)}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? 'rgba(79,143,255,.07)' : '#181c25',
        border: `1px solid ${hov ? '#4f8fff' : '#252c3d'}`,
        borderRadius: 10,
        padding: '10px 6px 7px',
        cursor: 'pointer',
        textAlign: 'center',
        transition: 'all .12s',
        transform: hov ? 'translateY(-1px)' : 'none',
      }}
    >
      <div style={{ fontSize: 22, marginBottom: 4, lineHeight: 1 }}>{item.ic}</div>
      <div style={{ fontSize: 10, color: '#7a8aaa', lineHeight: 1.2, marginBottom: 2 }}>{item.n}</div>
      <div style={{ fontSize: 10, color: '#00d4aa', fontWeight: 600 }}>
        {Math.round(item.mat + item.pose).toLocaleString()}€
      </div>
    </div>
  )
}
