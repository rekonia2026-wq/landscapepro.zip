'use client'
import { useRef, useEffect, useCallback, useState } from 'react'
import { useStore } from '../lib/store'

export default function Canvas2D() {
  const canvasRef = useRef(null)
  const containerRef = useRef(null)
  const dragRef = useRef(null)
  const {
    objects, selected, tool, zoom, gridOn, snapOn,
    terrainW, terrainH,
    addObject, updateObject, setSelected,
    setZoom,
  } = useStore()

  const [toast, setToast] = useState({ msg: '', show: false })
  const [coords, setCoords] = useState({ x: '0.0', y: '0.0' })
  const pendingDrop = useRef(null)

  const showToast = (msg) => {
    setToast({ msg, show: true })
    setTimeout(() => setToast(t => ({ ...t, show: false })), 2200)
  }

  // Expose drop handler to parent
  useEffect(() => {
    window.__canvasDrop = (item) => {
      const cw = containerRef.current
      if (!cw) return
      const r = cw.getBoundingClientRect()
      const x = r.width / 2 + (Math.random() - .5) * 100
      const y = r.height / 2 + (Math.random() - .5) * 80
      addObject(item, x, y)
      showToast(`${item.ic} ${item.n} ajouté !`)
    }
  }, [addObject])

  // Draw grid & terrain
  const draw = useCallback(() => {
    const cv = canvasRef.current
    const ctr = containerRef.current
    if (!cv || !ctr) return
    cv.width = ctr.clientWidth
    cv.height = ctr.clientHeight
    const ctx = cv.getContext('2d')
    const W = cv.width, H = cv.height
    ctx.clearRect(0, 0, W, H)

    if (gridOn) {
      const gs = 40 * zoom
      ctx.strokeStyle = 'rgba(37,44,61,0.9)'
      ctx.lineWidth = .5
      for (let x = 0; x < W; x += gs) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
      for (let y = 0; y < H; y += gs) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
      const mgs = gs * 2
      ctx.strokeStyle = 'rgba(46,56,80,.7)'
      ctx.lineWidth = .8
      for (let x = 0; x < W; x += mgs) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke() }
      for (let y = 0; y < H; y += mgs) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke() }
    }

    // Terrain outline
    const pw = terrainW * 40 * zoom
    const ph = terrainH * 40 * zoom
    const ox = (W - pw) / 2
    const oy = (H - ph) / 2
    ctx.fillStyle = 'rgba(61,90,56,.06)'
    ctx.fillRect(ox, oy, pw, ph)
    ctx.strokeStyle = 'rgba(0,212,170,.5)'
    ctx.lineWidth = 2
    ctx.setLineDash([10, 5])
    ctx.strokeRect(ox, oy, pw, ph)
    ctx.setLineDash([])

    // Axes
    ctx.strokeStyle = 'rgba(0,212,170,.1)'
    ctx.lineWidth = 1
    ctx.beginPath(); ctx.moveTo(ox, oy + ph / 2); ctx.lineTo(ox + pw, oy + ph / 2); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(ox + pw / 2, oy); ctx.lineTo(ox + pw / 2, oy + ph); ctx.stroke()

    // Corner dots
    ctx.fillStyle = 'rgba(0,212,170,.8)'
    [[ox, oy], [ox + pw, oy], [ox + pw, oy + ph], [ox, oy + ph]].forEach(([cx, cy]) => {
      ctx.beginPath(); ctx.arc(cx, cy, 3.5, 0, Math.PI * 2); ctx.fill()
    })

    // Labels
    ctx.fillStyle = 'rgba(0,212,170,.6)'
    ctx.font = '500 11px Inter,sans-serif'
    ctx.textAlign = 'center'
    ctx.fillText(`← ${terrainW}m →`, ox + pw / 2, oy - 10)
    ctx.save(); ctx.translate(ox - 12, oy + ph / 2); ctx.rotate(-Math.PI / 2)
    ctx.fillText(`← ${terrainH}m →`, 0, 0); ctx.restore()
  }, [gridOn, zoom, terrainW, terrainH])

  useEffect(() => { draw() }, [draw, objects])

  useEffect(() => {
    const ro = new ResizeObserver(draw)
    if (containerRef.current) ro.observe(containerRef.current)
    return () => ro.disconnect()
  }, [draw])

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e) => {
      if (document.activeElement.tagName === 'INPUT') return
      if (e.key === 'Delete' && selected) useStore.getState().deleteObject(selected)
      if (e.key === 'Escape') setSelected(null)
      if (e.key === 'd' && selected) useStore.getState().duplicateObject(selected)
      if (e.key === '+' || e.key === '=') setZoom(zoom + .25)
      if (e.key === '-') setZoom(zoom - .25)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [selected, zoom, setZoom, setSelected])

  const snap = (v) => {
    if (!snapOn) return v
    const gs = 40 * zoom
    return Math.round(v / gs) * gs
  }

  const onMouseMove = (e) => {
    const r = containerRef.current?.getBoundingClientRect()
    if (!r) return
    const mx = ((e.clientX - r.left) / zoom / 40).toFixed(1)
    const my = ((e.clientY - r.top) / zoom / 40).toFixed(1)
    setCoords({ x: mx, y: my })
    if (dragRef.current) {
      const nx = snap(e.clientX - r.left - dragRef.current.ox)
      const ny = snap(e.clientY - r.top - dragRef.current.oy)
      updateObject(dragRef.current.id, {
        x: Math.max(0, Math.min(nx, r.width - 40)),
        y: Math.max(0, Math.min(ny, r.height - 40)),
      })
    }
  }

  const onMouseUp = () => { dragRef.current = null }

  const onBgClick = (e) => {
    if (e.target === containerRef.current || e.target === canvasRef.current) setSelected(null)
  }

  const startDrag = (e, id) => {
    e.preventDefault(); e.stopPropagation()
    const r = containerRef.current?.getBoundingClientRect()
    const obj = objects.find(o => o.id === id)
    if (!obj || !r) return
    dragRef.current = { id, ox: e.clientX - r.left - obj.x, oy: e.clientY - r.top - obj.y }
    setSelected(id)
  }

  return (
    <div
      ref={containerRef}
      style={{ position: 'relative', background: '#0a0c10', overflow: 'hidden', flex: 1 }}
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onClick={onBgClick}
    >
      <canvas ref={canvasRef} style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }} />

      {/* Objects */}
      {objects.map(obj => (
        <div
          key={obj.id}
          className={`placed-obj${obj.id === selected ? ' selected' : ''}`}
          style={{
            left: obj.x,
            top: obj.y,
            transform: `rotate(${obj.rot || 0}deg)`,
          }}
          onMouseDown={e => startDrag(e, obj.id)}
          onClick={e => { e.stopPropagation(); setSelected(obj.id) }}
        >
          <div style={{ fontSize: 22, lineHeight: 1 }}>{obj.item.ic}</div>
          <div style={{
            fontSize: 9, color: 'rgba(221,228,240,.5)',
            background: 'rgba(10,12,16,.75)', borderRadius: 3,
            padding: '1px 4px', maxWidth: 64, overflow: 'hidden',
            textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          }}>{obj.item.n}</div>
        </div>
      ))}

      {/* HUD top-left */}
      <div style={{ position: 'absolute', top: 10, left: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <HudChip>📍 X: {coords.x}m — Y: {coords.y}m</HudChip>
        <HudChip>📐 Terrain: {terrainW}×{terrainH}m</HudChip>
        <HudChip>🧱 Objets: {objects.length}</HudChip>
        {selected && <HudChip accent>✅ {objects.find(o => o.id === selected)?.item.n}</HudChip>}
      </div>

      {/* HUD bottom-center */}
      <div style={{
        position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)',
        display: 'flex', gap: 4, alignItems: 'center',
        background: 'rgba(14,17,22,.92)', border: '1px solid #2e3850',
        borderRadius: 10, padding: '6px 10px', backdropFilter: 'blur(8px)',
      }}>
        <HudBtn onClick={() => setZoom(zoom - .25)}>−</HudBtn>
        <span style={{ fontSize: 11, color: '#dde4f0', minWidth: 42, textAlign: 'center', cursor: 'pointer' }}
          onClick={() => setZoom(1)}>{Math.round(zoom * 100)}%</span>
        <HudBtn onClick={() => setZoom(zoom + .25)}>+</HudBtn>
        <Vsep />
        <HudBtn onClick={() => showToast('🏡 Projet exemple chargé !')}>✨ Exemple</HudBtn>
        <HudBtn onClick={() => { useStore.getState().clearAll(); showToast('Plan vidé') }} danger>🗑️ Vider</HudBtn>
      </div>

      {/* Zoom info */}
      <div style={{
        position: 'absolute', bottom: 10, right: 10,
        background: 'rgba(14,17,22,.8)', border: '1px solid #252c3d',
        borderRadius: 6, padding: '3px 10px', fontSize: 10, color: '#4a5570',
      }}>Zoom {Math.round(zoom * 100)}% — Grille 0.5m — WebGL</div>

      {/* Toast */}
      <div className={`toast${toast.show ? ' show' : ''}`}>{toast.msg}</div>
    </div>
  )
}

function HudChip({ children, accent }) {
  return (
    <div style={{
      background: 'rgba(14,17,22,.85)', border: `1px solid ${accent ? 'rgba(0,212,170,.3)' : '#2e3850'}`,
      borderRadius: 6, padding: '4px 10px', fontSize: 10,
      color: accent ? '#00d4aa' : '#7a8aaa', display: 'flex', alignItems: 'center', gap: 4,
    }}>{children}</div>
  )
}

function HudBtn({ children, onClick, danger }) {
  return (
    <button onClick={onClick} style={{
      background: 'none', border: 'none', color: danger ? '#e05c5c' : '#7a8aaa',
      padding: '4px 10px', cursor: 'pointer', fontSize: 12, borderRadius: 6,
      transition: 'all .12s', fontFamily: 'inherit',
    }}
      onMouseEnter={e => { e.target.style.background = '#181c25'; e.target.style.color = danger ? '#f87171' : '#dde4f0' }}
      onMouseLeave={e => { e.target.style.background = 'none'; e.target.style.color = danger ? '#e05c5c' : '#7a8aaa' }}
    >{children}</button>
  )
}

function Vsep() {
  return <div style={{ width: 1, height: 18, background: '#252c3d' }} />
}
